AstraZeneca Evidence Images — James Saint

Prepared: 2025-10-12 20:23:42Z

Provenance watermark on each image: 'Source: GP record provided to patient – April 2025'

Files:

- 2021-03-31_Home_Visit_SMS.png
  31-Mar-2021 — SMS note offering home visit for vaccination on 1 Apr.
  SHA-256: 742bde641f2d018f97669dd44dc24b899d41d3c9ea9689bb06a57a731ce22a2d

- 2021-04-01_First_Dose_Record.png
  01-Apr-2021 — First dose: Vaxzevria (ChAdOx1-S) 0.5 ml. Batch PW40008. IM left deltoid.
  SHA-256: 6ff9e01d03963b22df5c956754854cd50d99ab2f96edb3cb9bd0a17e3f5da151

- 2021-06-22_Second_Dose_Record.png
  22-Jun-2021 — Second dose: Vaxzevria (ChAdOx1-S) 0.5 ml. Batch PV46690. Location recorded N9J0U – Emsworth Baptist Church.
  SHA-256: 4cd21bcabd59c67fc5da1b61a0a1c9c02a8384b5d0bbbf101f568693fcd83b1d


Notes:
- Images lightly cleaned (auto-contrast), cropped, and bordered for legibility.
- Originals preserved by the user; these are presentation copies.
